from flask import *
from public import public
from admin import admin
from user import user
from doctor import doctor


app=Flask(__name__,template_folder='templates')


app.secret_key="hvkjgjgjyg"
app.register_blueprint(public)
app.register_blueprint(admin)
app.register_blueprint(user)
app.register_blueprint(doctor)


app.run(debug=True)