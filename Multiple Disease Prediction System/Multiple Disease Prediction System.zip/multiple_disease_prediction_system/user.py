from flask import *
from database import *
import numpy as np
import pickle

user=Blueprint('user',__name__)

diabetes_predict=pickle.load(open('diabetes.pkl', 'rb'))          
heart_predict=pickle.load(open('heart.pkl', 'rb'))
parkinsons_predict=pickle.load(open('parkinsons.pkl', 'rb'))


@user.route('/userhome')
def userhome():
    return render_template("userhome.html") 

@user.route('/diabetes', methods=['get', 'post'])
def diabetes():
    return render_template("diabetes.html")

@user.route('/parkinsons', methods=['get', 'post'])
def parkinsons():
    return render_template("parkinsons.html")

@user.route('/heart', methods=['get', 'post'])
def heart():
    return render_template("heart.html")


# @user.route('/predictdiabetes',methods=['POST']) 
# def predictdiabetes():     
#     #int_features=[float(x) if isinstance(x, (int, float)) else 0.0 for x in request.form.values()]
#     int_features=[]
#     for data in request.form.values():
#         int_features.append(float(data))
#     processed_feature_diabetes=[np.array(int_features,dtype=float)]
#     prediction=diabetes_predict.predict(processed_feature_diabetes)
#     if prediction[0]==1:
#         display_text="This person has Diabetes"
#     else:
#         display_text="This person doesn't have Diabetes"
#     return render_template('diabetes.html',output_text="Result: {}".format(display_text))


@user.route('/predictdiabetes',methods=['POST']) 
def predictdiabetes():
    Pregnancies=request.form['Pregnancies']
    Glucose=request.form['Glucose']
    BloodPressure=request.form['BloodPressure']
    SkinThickness=request.form['SkinThickness']
    Insulin=request.form['Insulin']
    BMI=request.form['BMI']
    DiabetesPedigreeFunction=request.form['DiabetesPedigreeFunction']
    Age=request.form['Age']

    #int_features=[float(x) if isinstance(x, (int, float)) else 0.0 for x in request.form.values()]
    int_features=[]
    for data in request.form.values():
        int_features.append(float(data))
    processed_feature_diabetes=[np.array(int_features,dtype=float)]
    prediction=diabetes_predict.predict(processed_feature_diabetes)
    if prediction[0]==1:
        display_text="This person has Diabetes"
        # qry = "INSERT INTO `diabetes`(`doctor_id`,`patient_id`," \
        #       "`pregnancies`,`glucose`,`bloodpressure`,`skinthickness`,`insulin`," \
        #       "`bmi`,`diabetespedigreefunction`,`age`,`result`)VALUES (null, '%s', '%s','%s', '%s', '%s','%s', '%s', null,'%s', '%s')" % (
        #           '0', session['user'], Pregnancies, Glucose, BloodPressure, SkinThickness, Insulin, BMI,
        #           DiabetesPedigreeFunction, Age, str(display_text))
        qry = "INSERT INTO `diabetes`(`diabetes_id`,`doctor_id`,`patient_id`," \
              "`pregnancies`,`glucose`,`bloodpressure`,`skinthickness`,`insulin`," \
              "`bmi`,`diabetespedigreefunction`,`age`,`result`)VALUES(NULL,'" + str(0) + "','" + str(session[
                  'user']) + "','" + str(Pregnancies) + "','" + str(Glucose) + "','" + str(BloodPressure) + "','" + str(
            SkinThickness) + "','" + str(Insulin) + "','" + str(BMI) + "','" + str(
            DiabetesPedigreeFunction) + "','" + str(Age) + "','" + str(
            display_text) + "')"
        insert(qry)


    else:
        display_text="This person does not have Diabetes"
        # qry = "INSERT INTO `diabetes`(`doctor_id`,`patient_id`,`pregnancies`,`glucose`,`bloodpressure`,`skinthickness`,`insulin`,`bmi`,`diabetespedigreefunction`,`age`,`result`)VALUES (null,'%s', '%s','%s', '%s', '%s','%s', '%s', '%s','%s', '%s')" % (
        #       '0', session['user'], Pregnancies, Glucose, BloodPressure, SkinThickness, Insulin, BMI,
        #       DiabetesPedigreeFunction, Age, str(display_text))
        qry = "INSERT INTO `diabetes`(`diabetes_id`,`doctor_id`,`patient_id`," \
               "`pregnancies`,`glucose`,`bloodpressure`,`skinthickness`,`insulin`," \
               "`bmi`,`diabetespedigreefunction`,`age`,`result`)VALUES(NULL,'"+str(0)+"','" + str(session['user'] )+ "','" +str(Pregnancies)+ "','" + str(Glucose) + "','" + str(BloodPressure) + "','" + str(SkinThickness) + "'," \
                              "'" + str(Insulin) + "','" + str(BMI) + "','" + str(DiabetesPedigreeFunction) + "','" + str(Age) + "','" + str(
            display_text) + "')"
        insert(qry)
        # qryy = "INSERT INTO `diabetes`(`diabetes_id`,`doctor_id`,`patient_id`," \
        #        "`pregnancies`,`glucose`,`bloodpressure`,`skinthickness`,`insulin`," \
        #        "`bmi`,`diabetespedigreefunction`,`age`,`result`)VALUES(NULL,'"+0+"','" + session[
        #            'user'] + "','" + Pregnancies + "','" + Glucose + "','" + BloodPressure + "','" + SkinThickness + "','" + Insulin + "','" + BMI + "','" + DiabetesPedigreeFunction + "','" + Age + "','" + str(
        #     display_text) + "')"
        # insert(qryy)
    return render_template('diabetes.html',output_text="Result: {}".format(display_text))

       
# @user.route('/predictparkinson',methods=['POST']) 
# def predictparkinsons():     
#     #int_features=[float(x) if isinstance(x, (int, float)) else 0.0 for x in request.form.values()]
#     int_features=[]
#     for data in request.form.values():
#         int_features.append(float(data))
#     processed_feature_parkinsons=[np.array(int_features,dtype=float)]
#     prediction=parkinsons_predict.predict(processed_feature_parkinsons)
#     if prediction[0]==1:
#         display_text="This person has Parkinson's"
#     else:
#         display_text="This person doesn't have Parkinson's"
#     return render_template('parkinsons.html',output_text="Result: {}".format(display_text))

@user.route('/predictparkinson',methods=['POST']) 
def predictparkinsons():
    mdvpfo=request.form['fo']
    mdvpfhi=request.form['fhi']
    mdvpflo=request.form['flo']
    mdvpjitter=request.form['jitterpercentage']
    mdvpjitterabs=request.form['jitterabs']
    mdvprap=request.form['rap']
    # mdvpjitter=request.form['mdvpjitter']
    mdvpppq=request.form['ppq']
    jitterddp=request.form['jitterddp']
    mdvpshimmer=request.form['shimmer']
    mdvpshimmerdb=request.form['shimmerdb']
    shimmerapqthree=request.form['apq3']
    shimmerapqfive=request.form['apq5']
    mdvpapq=request.form['apq']
    shimmerdda=request.form['shimmerdda']
    nhr=request.form['nhr']
    hnr=request.form['hnr']
    rpde=request.form['rpde']
    # hnr=request.form['hnr']
    dfa=request.form['dfa']
    spreadone=request.form['spread1']
    spreadtwo=request.form['spread2']
    dtwo=request.form['dtwo']
    ppe=request.form['ppe']

    #int_features=[float(x) if isinstance(x, (int, float)) else 0.0 for x in request.form.values()]
    int_features=[]
    for data in request.form.values():
        int_features.append(float(data))
    processed_feature_parkinsons=[np.array(int_features,dtype=float)]
    prediction=parkinsons_predict.predict(processed_feature_parkinsons)
    if prediction[0]==1:
        display_text="This person has Parkinsons"
        qry="INSERT INTO `parkinson`(`parkinson_id`,`doctor_id`,`patient_id`,`mdvpfo`,`mdvpfhi`,`mdvpflo`,"\
"`mdvpjitter`,`mdvpjitterabs`,`mdvprap`,`mdvpppq`,`jitterddp`,"\
"`mdvpshimmer`,`mdvpshimmerdb`,`shimmerapqthree`,`shimmerapqfive`,"\
"`mdvpapq`,`shimmerdda`,`nhr`,`hnr`,`rpde`,"\
"`dfa`,`spreadone`,`spreadtwo`,`dtwo`,`ppe`,`result`)VALUES(null,'"+str(0)+"','"+str(session['user'] )+"','"+str(mdvpfo)+"','"+str(mdvpfhi)+"','"+str(mdvpflo)+"'," \
       "'"+str(mdvpjitter)+"','"+str(mdvpjitterabs)+"','"+str(mdvprap)+"','"+str(mdvpppq)+"','"+str(jitterddp)+"'," \
         "'"+str(mdvpshimmer)+"','"+str(mdvpshimmerdb)+"','"+str(shimmerapqthree)+"','"+str(shimmerapqfive)+"'," \
        "'"+str(mdvpapq)+"','"+str(shimmerdda)+"','"+str(nhr)+"','"+str(hnr)+"','"+str(rpde)+"','"+str(dfa)+"','"+str(spreadone)+"','"+str(spreadtwo)+"'," \
                        "'"+str(dtwo)+"','"+str(ppe)+"','"+str(display_text)+"')"
        insert(qry)

    else:
        display_text="This person does not have Parkinsons"
        qry = "INSERT INTO `parkinson`(`parkinson_id`,`doctor_id`,`patient_id`,`mdvpfo`,`mdvpfhi`,`mdvpflo`," \
              "`mdvpjitter`,`mdvpjitterabs`,`mdvprap`,`mdvpppq`,`jitterddp`," \
              "`mdvpshimmer`,`mdvpshimmerdb`,`shimmerapqthree`,`shimmerapqfive`," \
              "`mdvpapq`,`shimmerdda`,`nhr`,`hnr`,`rpde`," \
              "`dfa`,`spreadone`,`spreadtwo`,`dtwo`,`ppe`,`result`)VALUES(null,'" + str(0) + "','" + str(
            session['user']) + "','" + str(mdvpfo) + "','" + str(mdvpfhi) + "','" + str(mdvpflo) + "'," \
                                                                                                   "'" + str(
            mdvpjitter) + "','" + str(mdvpjitterabs) + "','" + str(mdvprap) + "','" + str(mdvpppq) + "','" + str(
            jitterddp) + "'," \
                         "'" + str(mdvpshimmer) + "','" + str(mdvpshimmerdb) + "','" + str(
            shimmerapqthree) + "','" + str(shimmerapqfive) + "'," \
                                                             "'" + str(mdvpapq) + "','" + str(shimmerdda) + "','" + str(
            nhr) + "','" + str(hnr) + "','" + str(rpde) + "','" + str(dfa) + "','" + str(spreadone) + "','" + str(
            spreadtwo) + "'," \
                         "'" + str(dtwo) + "','" + str(ppe) + "','" + str(display_text) + "')"
        insert(qry)

    return render_template('parkinsons.html',output_text="Result: {}".format(display_text))


# @user.route('/predictheart',methods=['POST']) 
# def predictheart():     
#     #int_features=[float(x) if isinstance(x, (int, float)) else 0.0 for x in request.form.values()]
#     int_features=[]
#     for data in request.form.values():
#         int_features.append(float(data))
#     processed_feature_heart=[np.array(int_features,dtype=float)]
#     prediction=heart_predict.predict(processed_feature_heart)
#     if prediction[0]==1: 
#         display_text="This person has Heart Disease"
#     else:
#         display_text="This person doesn't have Heart Disease"
#     return render_template('heart.html',output_text="Result: {}".format(display_text))


@user.route('/predictheart',methods=['POST']) 
def predictheart():
    Age=request.form['age']
    sex=request.form['sex']
    cp=request.form['cp']
    trestbps=request.form['trestbps']
    chol=request.form['chol']
    fbs=request.form['fbs']
    restecg=request.form['restecg']
    thalach=request.form['thalach']
    exang=request.form['exang']
    oldpeak=request.form['oldpeak']
    slope=request.form['slope']
    ca=request.form['ca']
    thal=request.form['thal']

    #int_features=[float(x) if isinstance(x, (int, float)) else 0.0 for x in request.form.values()]
    int_features=[]
    for data in request.form.values():
        int_features.append(float(data))
    processed_feature_heart=[np.array(int_features,dtype=float)]
    prediction=heart_predict.predict(processed_feature_heart)
    if prediction[0]==1: 
        display_text="This person has Heart Disease"
        qry="INSERT INTO `heart`(`heart_id`,`doctor_id`,`patient_id`,`age`,`sex`," \
            "`cp`,`trestbps`,`chol`,`fbs`,`restecg`," \
            "`thalach`,`exang`,`oldpeak`,`slope`,`ca`," \
            "`thal`,`result`)VALUES(NULL,'"+str(0)+"','"+str(session['user'])+"','"+str(Age)+"','"+str(sex)+"','"+str(cp)+"','"+str(trestbps)+"'," \
                     "'"+str(chol)+"','"+str(fbs)+"','"+str(restecg)+"','"+str(thalach)+"','"+str(exang)+"','"+str(oldpeak)+"','"+str(slope)+"','"+str(ca)+"','"+str(thal)+"','"+str(display_text)+"')"
        insert(qry)
    else:
        display_text="This person does not have Heart Disease"
        qry = "INSERT INTO `heart`(`heart_id`,`doctor_id`,`patient_id`,`age`,`sex`," \
              "`cp`,`trestbps`,`chol`,`fbs`,`restecg`," \
              "`thalach`,`exang`,`oldpeak`,`slope`,`ca`," \
              "`thal`,`result`)VALUES(NULL,'" + str(0) + "','" + str(session['user']) + "','" + str(Age) + "','" + str(
            sex) + "','" + str(cp) + "','" + str(trestbps) + "'," \
                                                             "'" + str(chol) + "','" + str(fbs) + "','" + str(
            restecg) + "','" + str(thalach) + "','" + str(exang) + "','" + str(oldpeak) + "','" + str(
            slope) + "','" + str(ca) + "','" + str(thal) + "','" + str(display_text) + "')"
        insert(qry)
    return render_template('heart.html',output_text="Result: {}".format(display_text))
    
    
@user.route('/userfeedback', methods=['get', 'post'])
def userfeedback():
    if request.method == 'POST' and 'feedback' in request.form:
        title = request.form['title']
        description = request.form['description']
        qry = "INSERT INTO feedback (date, title, description) VALUES (curdate(), '%s', '%s')" % (title, description)
        insert(qry) 
        return redirect(url_for('user.userfeedback'))
    return render_template("userfeedback.html")


@user.route('/userappointment',methods=['get', 'post'])
def userappointment():
    id=request.args['id']
    if 'appointment' in request.form:
        date=request.form['date']
        name=request.form['name']
        disease=request.form['disease']
        qry4="insert into appointment values(null,'%s','%s','%s','%s','%s')"%(id,session['user'],date,name,disease)
        insert(qry4)
        return redirect(url_for('user.userdoctor_view'))
    return render_template("userappointment.html")


@user.route('/userdoctor_view',methods=['post','get'])
def userdoctor_view():
    data={}
    qry="select*from doctor"
    data['doc']=select(qry)
    return render_template("userdoctor_view.html",data=data)


@user.route('/user_view_prescription',methods=['post','get'])
def user_view_prescription():
    data={}
    qry="select*from prescription inner join appointment using (appointment_id) inner join patient using (patient_id) where patient_id='%s'"%(session['user'])
    data['prescription']=select(qry)
    return render_template("user_view_prescription.html",data=data)