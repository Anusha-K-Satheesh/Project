from flask import *
from database import *

public=Blueprint('public',__name__) 

@public.route('/')
def home():
    return render_template("home.html")

@public.route('/index')
def index():
    return render_template("index.html")

@public.route('/login',methods=['get','post'])
def login():
    if 'login' in request.form:
        username=request.form['username']
        password=request.form['password']
        login="select * from login where username='%s' and password='%s'"%(username,password)
        res=select(login)
        if res:
            session['lid']=res[0]['login_id']
            if res[0]['usertype']=='admin':
                return redirect(url_for('admin.adminhome'))
            if res[0]['usertype']=='user':
                qry="select *from patient where login_id='%s'"%(session['lid'])
                res=select(qry)
                session['user']=res[0]['patient_id']
                return redirect(url_for('user.userhome'))
            if res[0]['usertype']=='doctor':
                qry6="select * from doctor where login_id='%s'"%(session['lid'])
                res8=select(qry6)
                session['doc']=res8[0]['doctor_id']
                return redirect(url_for('doctor.doctorhome'))
            else:
                return """<script>alert('incorrect username and password :(');window.location='/login'</script>"""
    return render_template("login.html")



@public.route('/registration',methods=['get','post'])
def registration():
    if 'reg' in request.form:
        firstname=request.form['firstname']
        lastname=request.form['lastname']
        place=request.form['place']
        mobile=request.form['mobile']
        email=request.form['email'] 
        age=request.form['age']
        username=request.form['uname']
        password=request.form['pass']

        qry="insert into login values(null,'%s','%s','user')"%(username,password)
        logid=insert(qry)

        qry1="insert into patient values(null,'%s','%s','%s','%s','%s','%s','%s')"%(logid,firstname,lastname,place,mobile,email,age)
        insert(qry1)
        return redirect(url_for('public.home'))
    return render_template("registration.html")

@public.route('/doctoregister',methods=['get','post'])
def doctoregister():
    if 'reg' in request.form:
        firstname=request.form['firstname']
        lastname=request.form['lastname']
        place=request.form['place']
        mobile=request.form['mobile']
        email=request.form['email'] 
        designation=request.form['designation']
        username=request.form['uname']
        password=request.form['pass']
        qry="insert into login values(null,'%s','%s','pending')"%(username,password)
        logid=insert(qry)
        qry2="insert into doctor values(null,'%s','%s','%s','%s','%s','%s','%s','pending')"%(logid,firstname,lastname,place,mobile,email,designation)
        insert(qry2)
        return redirect(url_for('public.home'))
    return render_template("doctoregister.html")



