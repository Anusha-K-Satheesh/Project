from flask import *
from database import *


doctor=Blueprint('doctor',__name__)

@doctor.route('/doctorhome')
def doctorhome():
    return render_template("doctorhome.html") 

@doctor.route('/doctors',methods=['get','post'])
def doctors():
    data={}
    dd="select * from doctor where doctor_id='%s'" %(session['doc'])
    data['viewdoc']=select(dd)
    if'action' in request.args:
        action=request.args['action']
        id=request.args['id']
    else:
        action=None
    if action=='update':
        a="select * from doctor where doctor_id='%s'"%(id)
        data['up']=select(a)
    if 'update' in request.form:
        firstname=request.form['fname']
        lastname=request.form['lname']
        place=request.form['place']
        phone=request.form['phone']
        email=request.form['email']
        designation=request.form['designation']
        d="update doctor set fname='%s',lname='%s',place='%s',phone='%s',email='%s',designation='%s' where doctor_id='%s'"%( firstname,lastname,place,phone,email,designation,id)
        update(d)
        return '''<script>alert("Updated");window.location="/doctors"</script>'''
    return render_template("doctors.html",data=data)


@doctor.route('/doctorappointment_view', methods=['get','post'])
def doctorappointment_view():
    data={}
    cc="select * from appointment inner join patient using(patient_id) inner join doctor using(doctor_id) where doctor_id='%s'"%(session['doc'])
    res=select(cc)
    data['appointment']=res
    return render_template("doctorappointment_view.html",data=data)


@doctor.route('/doctor_view_details/<id>', methods=['GET', 'POST'])
def doctor_view_details(id):
    data = {}
    data1 = {}
    data2 = {}
    # Fetch data for Parkinson's disease
    cc = "SELECT * FROM `parkinson` WHERE `patient_id`='" + str(id) + "'"
    res = select(cc)
    data['parkinson'] = res
    # Fetch data for Heart disease
    ccc = "SELECT * FROM `heart` WHERE `patient_id`='" + str(id) + "'"
    res1 = select(ccc)
    data1['heart'] = res1
    # Fetch data for Diabetes
    cccc = "SELECT * FROM `diabetes` WHERE `patient_id`='" + str(id) + "'"
    res2 = select(cccc)
    data2['diabetes'] = res2
    if res2:
        data2['diabetes'] = res2
    # Check the disease from the appointment
    qry = "SELECT disease FROM appointment WHERE patient_id='" + str(id) + "'"
    appointment_result = select(qry)
    if appointment_result:
        patient_disease = appointment_result[0]['disease']
        if patient_disease == "Heart":
            return render_template("heart_table.html", data1=data1)
        elif patient_disease == "Parkinson":
            return render_template("parkinsons_table.html", data=data)
        elif patient_disease == "Diabetes":
            return render_template("diabetes_table.html", data2=data2)
    # If no appointment or disease found, render a default template
    return render_template("doctorappointment_view.html")


@doctor.route('/prescription',methods=['post','get'])
def prescription():
    if 'id' in request.args:
        id=request.args['id']
    if 'prescription' in request.form:
        date=request.form['date']
        medicine=request.form['medicine']
        description=request.form['description']
        qry="insert into prescription values(null,'%s','%s','%s','%s')"%(id,date,medicine,description)
        insert(qry)
        return redirect(url_for('doctor.doctorappointment_view'))
    return render_template("prescription.html")


@doctor.route('/changepassword',methods=['get','post'])
def changepassword():
    data={}
    if 'changepwd' in request.form:
        pwd1=request.form['newpassword']
        pwd2=request.form['confirmpassword']
        qry="update login set password='%s' where login_id='%s'" %(pwd1,pwd2,session['lid'])
        update(qry)
        return redirect(url_for('doctor.doctors'))
    return render_template("changepassword.html")


@doctor.route('/doctor_complaint', methods=['get', 'post'])
def doctorcomplaint():
    if request.method == 'POST' and 'complaints' in request.form:
        doctorname = request.form['doctorname']
        complaints = request.form['complaints']
        qry = "INSERT INTO complaints (date, name, complaint) VALUES (curdate(), '%s', '%s')" % (doctorname, complaints)
        insert(qry)  
        return redirect(url_for('doctor.doctorcomplaint'))
    return render_template("doctor_complaint.html")
    
    