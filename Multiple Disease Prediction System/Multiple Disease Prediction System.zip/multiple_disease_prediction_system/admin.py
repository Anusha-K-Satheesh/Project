from flask import *
from database import *

admin=Blueprint('admin',__name__)

@admin.route('/adminhome')
def adminhome():
    return render_template("adminhome.html") 

@admin.route('/admindoctor_view')
def admindoctor_view():
    data={}
    d="select * from doctor"
    data['view']=select(d)
    if 'action' in request.args:
        actn=request.args['action']
        lid=request.args['id']
        ids=request.args['ids']
        print("//////////////////////",ids)
    else:
        actn=None
    if actn =="aprove":
        opo="update login set usertype='doctor' where login_id='%s'"%(lid)
        update(opo)
        pp="update doctor set status='approved:)' where doctor_id='%s'"%(ids)
        update(pp)
        return """<script>alert('Approved');window.location='/admindoctor_view'</script>"""
    if actn == "reject":
        a="delete from doctor where doctor_id='%s'"%(ids)
        delete(a)
        return """<script>alert('Rejected');window.location='/admindoctor_view'</script>"""
    return render_template('/admindoctor_view.html',data=data)


@admin.route('/adminusers_view')
def adminusers_view():
    data={}
    d="select * from patient"
    data['view']=select(d)
    return render_template('/adminusers_view.html',data=data)


@admin.route('/adminfeedback_view')
def adminfeedback_view():
    data={}
    d="select * from feedback"
    data['view']=select(d)
    return render_template('/adminfeedback_view.html',data=data)


@admin.route('/admincomplaint_view')
def admincomplaint_view():
    data={}
    d="select * from complaints"
    data['view']=select(d)
    return render_template('/admincomplaint_view.html',data=data)

@admin.route("/adminreport_view", methods=['GET', 'POST'])
def adminreport_view():
    data = {}
    if 'submit' in request.form:
        date = request.form['date']
        disease = request.form['disease']
        
        qry = "SELECT doctor.fname AS df, doctor.lname AS dl, appointment.name, appointment.date, appointment.disease FROM doctor INNER JOIN appointment ON doctor.doctor_id = appointment.doctor_id WHERE appointment.date = '{}' AND appointment.disease = '{}'".format(date, disease)
        
        res = select(qry)  # Pass the concatenated query string
        if res:
            data['que'] = res
        else:
            print("no data")

    return render_template("adminreport_view.html", data=data)


