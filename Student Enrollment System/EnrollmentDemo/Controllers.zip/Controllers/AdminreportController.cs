﻿//using EnrollmentDemo.DAL;
//using EnrollmentDemo.Models;
//using iText.Kernel.Pdf;
//using iText.Layout.Element;
//using iTextSharp.text;
//using iTextSharp.text.pdf;
//using System;
//using System.Collections.Generic;
//using System.IO;
//using System.Web.Mvc;

//namespace EnrollmentDemo.Controllers
//{
//    public class AdminreportController : Controller
//    {
//        private readonly StudentSignup_DAL _dal = new StudentSignup_DAL();
//        private readonly Course_DAL _courseDal = new Course_DAL();

//        // GET: AdminReport
//        public ActionResult Index()
//        {
//            return View();
//        }

//        [HttpPost]
//        public ActionResult GenerateReport(string reportType)
//        {
//            if (reportType == "StudentList")
//            {
//                var students = _dal.GetAllStudents();
//                return GenerateStudentListPDF(students);
//            }
//            else if (reportType == "EnrolledStudentList")
//            {
//                var enrolledStudents = _courseDal.EnrolledStudents();
//                return GenerateEnrolledStudentListPDF(enrolledStudents);
//            }

//            return RedirectToAction("Index");
//        }

//        private ActionResult GenerateStudentListPDF(List<StudentSignup> students)
//        {
//            using (MemoryStream stream = new MemoryStream())
//            {
//                Document document = new Document();
//                PdfWriter.GetInstance(document, stream);
//                document.Open();

//                // Add title and spacing
//                document.Add(new Paragraph("Student List"));
//                document.Add(new Paragraph(" "));

//                // Create a table with 5 columns
//                PdfPTable table = new PdfPTable(5);
//                table.AddCell("Student ID");
//                table.AddCell("First Name");
//                table.AddCell("Last Name");
//                table.AddCell("Email");
//                table.AddCell("Phone");

//                // Add student data to the table
//                foreach (var student in students)
//                {
//                    table.AddCell(student.studentid.ToString());
//                    table.AddCell(student.firstname);
//                    table.AddCell(student.lastname);
//                    table.AddCell(student.mail);
//                    table.AddCell(student.phone);
//                }

//                document.Add(table);
//                document.Close();

//                // Return the file result
//                return File(stream.ToArray(), "application/pdf", "StudentList.pdf");
//            }
//        }

//        private ActionResult GenerateEnrolledStudentListPDF(List<Enrollment> enrollments)
//        {
//            using (MemoryStream stream = new MemoryStream())
//            {
//                Document document = new Document();
//                PdfWriter.GetInstance(document, stream);
//                document.Open();

//                // Add title and spacing
//                document.Add(new Paragraph("Enrolled Student List"));
//                document.Add(new Paragraph(" "));

//                // Create a table with 3 columns
//                PdfPTable table = new PdfPTable(3);
//                table.AddCell("Student ID");
//                table.AddCell("Course Name");
//                table.AddCell("Enrollment Status");

//                // Add enrollment data to the table
//                foreach (var enrollment in enrollments)
//                {
//                    table.AddCell(enrollment.StudentId.ToString());
//                    table.AddCell(enrollment.CourseName);
//                    table.AddCell(enrollment.EnrollStatus);
//                }

//                document.Add(table);
//                document.Close();

//                // Return the file result
//                return File(stream.ToArray(), "application/pdf", "EnrolledStudentList.pdf");
//            }
//        }
//    }
//}
using EnrollmentDemo.DAL;
using EnrollmentDemo.Models;
using iTextSharp.text; // Use iTextSharp for PDF generation
using iTextSharp.text.pdf; // iTextSharp PDF writer
using System;
using System.Collections.Generic;
using System.IO;
using System.Web.Mvc;

namespace EnrollmentDemo.Controllers
{
    public class AdminreportController : Controller
    {
        private readonly StudentSignup_DAL _dal = new StudentSignup_DAL();
        private readonly Course_DAL _courseDal = new Course_DAL();

        // GET: AdminReport
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult GenerateReport(string reportType)
        {
            if (reportType == "StudentList")
            {
                var students = _dal.GetAllStudents();
                return GenerateStudentListPDF(students);
            }
            else if (reportType == "EnrolledStudentList")
            {
                var enrolledStudents = _courseDal.EnrolledStudents();
                return GenerateEnrolledStudentListPDF(enrolledStudents);
            }

            return RedirectToAction("Index");
        }

        private ActionResult GenerateStudentListPDF(List<StudentSignup> students)
        {
            using (MemoryStream stream = new MemoryStream())
            {
                Document document = new Document();
                PdfWriter.GetInstance(document, stream);
                document.Open();

                //// Add title and spacing
                //document.Add(new iTextSharp.text.Paragraph("Student List"));
                //document.Add(new iTextSharp.text.Paragraph(" "));
                Paragraph title = new Paragraph("Student List")
                {
                    Alignment = Element.ALIGN_CENTER // Center the title
                };
                document.Add(title);
                document.Add(new iTextSharp.text.Paragraph(" "));

                // Create a table with 5 columns
                PdfPTable table = new PdfPTable(4);
                //table.AddCell("Student ID");
                table.AddCell("First Name");
                table.AddCell("Last Name");
                table.AddCell("Email");
                table.AddCell("Phone");

                // Add student data to the table
                foreach (var student in students)
                {
                    //table.AddCell(student.studentid.ToString());
                    table.AddCell(student.firstname);
                    table.AddCell(student.lastname);
                    table.AddCell(student.mail);
                    table.AddCell(student.phone);
                }

                document.Add(table);
                document.Close();

                // Return the file result
                return File(stream.ToArray(), "application/pdf", "StudentList.pdf");
            }
        }

        private ActionResult GenerateEnrolledStudentListPDF(List<Enrollment> enrollments)
        {
            using (MemoryStream stream = new MemoryStream())
            {
                Document document = new Document();
                PdfWriter.GetInstance(document, stream);
                document.Open();

                //// Add title and spacing
                //document.Add(new iTextSharp.text.Paragraph("Enrolled Student List"));
                //document.Add(new iTextSharp.text.Paragraph(" "));
                Paragraph title = new Paragraph("Enrolled Student List")
                {
                    Alignment = Element.ALIGN_CENTER // Center the title
                };
                document.Add(title);
                document.Add(new iTextSharp.text.Paragraph(" "));

                // Create a table with 4 columns
                PdfPTable table = new PdfPTable(4);
                table.AddCell("First Name");
                table.AddCell("Last Name");
                table.AddCell("Course Name");
                table.AddCell("Enrollment Status");

                // Add enrollment data to the table
                foreach (var enrollment in enrollments)
                {
                    table.AddCell(enrollment.FirstName);
                    table.AddCell(enrollment.LastName);
                    table.AddCell(enrollment.CourseName);
                    table.AddCell(enrollment.EnrollStatus);
                }

                document.Add(table);
                document.Close();

                // Return the file result
                return File(stream.ToArray(), "application/pdf", "EnrolledStudentList.pdf");
            }
        }
    }
}
