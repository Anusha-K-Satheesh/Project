﻿using EnrollmentDemo.DAL;
using EnrollmentDemo.Models;
using System.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EnrollmentDemo.Controllers
{
    public class SignInController : Controller
    {
        private StudentSignup_DAL _dal = new StudentSignup_DAL();
        string connectionString = ConfigurationManager.ConnectionStrings["dbConnectionString"].ConnectionString;
        // GET: SignIn
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }
        // POST: SignIn
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(Signin model)
        {
            if (ModelState.IsValid)
            {
                // Check if the user is admin
                if (model.username == "admin" && model.password == "admin")
                {
                    // Redirect to the admin dashboard
                    return RedirectToAction("Index", "Adminhome");
                }
                else
                {
                    // Fetch the student from the database
                    StudentSignup student = _dal.GetStudentByUsername(model.username);

                    if (student != null)
                    {
                        System.Diagnostics.Debug.WriteLine("Username Retrieved: " + student.username);
                        System.Diagnostics.Debug.WriteLine("Decrypted Password Retrieved: " + student.password);

                        // Compare the entered plain-text password with the decrypted password
                        if (student.password == model.password)
                        {
                            // Successful login, store studentid in session and redirect
                            Session["studentid"] = student.studentid;
                            System.Diagnostics.Debug.WriteLine("Login successful.");
                            return RedirectToAction("Index", "Userhome");  // Redirect to the student dashboard
                        }
                        else
                        {
                            System.Diagnostics.Debug.WriteLine("Password mismatch. Entered: " + model.password + ", Decrypted: " + student.password);
                        }
                    }
                    else
                    {
                        System.Diagnostics.Debug.WriteLine("Username not found: " + model.username);
                    }

                    // If no match, display error message
                    ModelState.AddModelError("", "Invalid username or password.");
                }
            }

            return View(model);
        }
        // EncryptPassword method
        private string EncryptPassword(string password)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand command = new SqlCommand("SELECT CONVERT(VARCHAR, EncryptByPassPhrase('YourSecretPassphrase', @password))", con);
                command.Parameters.AddWithValue("@password", password);
                return command.ExecuteScalar().ToString();
            }
        }

        // GET: SignIn/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: SignIn/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: SignIn/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: SignIn/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: SignIn/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: SignIn/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: SignIn/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
