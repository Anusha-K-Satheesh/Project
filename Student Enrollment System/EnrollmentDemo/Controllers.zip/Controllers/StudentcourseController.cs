﻿using EnrollmentDemo.DAL;
using EnrollmentDemo.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
namespace EnrollmentDemo.Controllers
{
    public class StudentcourseController : Controller
    {
        private Course_DAL _dal = new Course_DAL();
        // GET: Studentcourse
        public ActionResult Index()
        {
            List<Course> courses = _dal.GetCourses();
            return View(courses);
        }
        public ActionResult Enroll(int id)
        {
            Session["CourseId"] = id; // Store the course ID in session for later use
            return RedirectToAction("UploadCertificates"); // Redirect to the UploadCertificates page
        }

        public ActionResult UploadCertificates()
        {
            // Render the certificate upload view
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UploadCertificates(Certificate model, HttpPostedFileBase tenCertificate, HttpPostedFileBase plusTwoCertificate)
        {
            if (ModelState.IsValid)
            {
                // Save the uploaded certificates
                if (tenCertificate != null && tenCertificate.ContentLength > 0)
                {
                    string tenPath = Path.Combine(Server.MapPath("~/Uploads"), tenCertificate.FileName);
                    tenCertificate.SaveAs(tenPath);
                    model.TenCertificatePath = tenPath;
                }

                if (plusTwoCertificate != null && plusTwoCertificate.ContentLength > 0)
                {
                    string plusTwoPath = Path.Combine(Server.MapPath("~/Uploads"), plusTwoCertificate.FileName);
                    plusTwoCertificate.SaveAs(plusTwoPath);
                    model.PlusTwoCertificatePath = plusTwoPath;
                }

                // Ensure the StudentId and CourseId are correctly set
                model.StudentId = (int)Session["studentid"];
                model.CourseId = (int)Session["CourseId"];

                // Store certificate info in database
                _dal.SaveCertificate(model); // Call a method in your DAL to save the certificate info

                // Optionally update enrollment status if needed
                _dal.UpdateEnrollmentStatus(model.StudentId, model.CourseId, "Pending");

                // Add the enrollment process after certificate upload
                _dal.EnrollStudent(model.StudentId, model.CourseId); // Enroll the student after uploading certificates

                return RedirectToAction("Index", "Studentcourse");
            }

            return View(model);
        }
        public ActionResult CourseStatus()
        {
            int studentId = (int)Session["studentid"]; // Get the student ID from session
            var enrollments = _dal.GetStudentEnrollments(studentId); // Fetch enrollments for the student
            return View(enrollments);
        }

























        //// GET: Studentcourse/Details/5
        //public ActionResult Details(int id)
        //{
        //    return View();
        //}

        //// GET: Studentcourse/Create
        //public ActionResult Create()
        //{
        //    return View();
        //}

        //// POST: Studentcourse/Create
        //[HttpPost]
        //public ActionResult Create(FormCollection collection)
        //{
        //    try
        //    {
        //        // TODO: Add insert logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}

        //// GET: Studentcourse/Edit/5
        //public ActionResult Edit(int id)
        //{
        //    return View();
        //}

        //// POST: Studentcourse/Edit/5
        //[HttpPost]
        //public ActionResult Edit(int id, FormCollection collection)
        //{
        //    try
        //    {
        //        // TODO: Add update logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}

        //// GET: Studentcourse/Delete/5
        //public ActionResult Delete(int id)
        //{
        //    return View();
        //}

        //// POST: Studentcourse/Delete/5
        //[HttpPost]
        //public ActionResult Delete(int id, FormCollection collection)
        //{
        //    try
        //    {
        //        // TODO: Add delete logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}
    }
}

