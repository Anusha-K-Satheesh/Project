﻿using EnrollmentDemo.DAL;
using EnrollmentDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EnrollmentDemo.Controllers
{
    public class AdmincourseController : Controller
    {
        private Course_DAL _dal = new Course_DAL();
        // GET: Admincourse
        public ActionResult Index()
        {
            List<Course> courses = _dal.GetCourses();
            return View(courses);
        }

        // GET: Admincourse/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Admincourse/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Admincourse/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Course course)
        {
            if (ModelState.IsValid)
            {
                string errorMessage;
                if (_dal.AddCourse(course, out errorMessage))
                {
                    // Course added successfully
                    return RedirectToAction("Index");
                }
                else
                {
                    // Display error message (e.g., duplicate course name)
                    ModelState.AddModelError("", errorMessage);
                }
            }
            return View(course);
        }
        public ActionResult EnrollmentManagement()
        {
            var enrollments = _dal.GetEnrolledStudents();
            //return View("AdminEnrollments", enrollments);
            return View(enrollments);
        }
        public ActionResult ViewCertificate(int studentId, int courseId)
        {
            var certificate = _dal.GetCertificate(studentId, courseId);
            return View(certificate);
        }
        public ActionResult UpdateEnrollmentStatus(int studentId, int courseId, string status)
        {
            // Call the DAL method to update enrollment status
            _dal.UpdateEnrollmentStatus(studentId, courseId, status);

            // Redirect back to the Enrollment Management view
            return RedirectToAction("EnrollmentManagement");
        }











        // GET: Admincourse/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Admincourse/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Admincourse/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Admincourse/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
