﻿using EnrollmentDemo.Models;
using EnrollmentDemo.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace EnrollmentDemo.Controllers
{
    public class StudentSignupController : Controller
    {
        string connectionString = ConfigurationManager.ConnectionStrings["dbConnectionString"].ConnectionString;
        public StudentSignup_DAL _dal = new StudentSignup_DAL();
        // GET: StudentSignup
        public ActionResult Index()
        {
            //return View();
            return RedirectToAction("Create");
        }

        // GET: StudentSignup/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: StudentSignup/Create
        public ActionResult Create()
        {
            var states = _dal.GetStates();
            ViewBag.StateList = new SelectList(states, "stateid", "statename"); // ViewBag - container for passing data from the controller to the view
            return View();
        }

        // POST: StudentSignup/Create
        [HttpPost]
        public ActionResult Create(StudentSignup model)
        {
            if (ModelState.IsValid)
            {
                // Call the method to insert the student data into the database
                _dal.InsertStudent(model);

                // Redirect to a different action after successful insertion
                return RedirectToAction("Index");
            }

            // If the model is invalid, repopulate the states dropdown
            var states = _dal.GetStates();
            ViewBag.StateList = new SelectList(states, "stateid", "statename");

            // Return the view with the current model to show validation errors
            return View(model);
        }
        public JsonResult GetCitiesByState(int stateId)
        {
            var cities = _dal.GetCitiesByState(stateId);
            return Json(cities.Select(c => new { c.cityid, c.cityname }), JsonRequestBehavior.AllowGet);
        }
        public ActionResult Profiles()
        {
            int studentId = (int)Session["studentid"]; // Get studentid from session
            StudentSignup student = _dal.GetStudentById(studentId);

            if (student != null)
            {
                return View(student); // Pass the student object to the view
            }
            return RedirectToAction("Index", "Home"); // Redirect if student not found
        }
        [HttpGet]
        public ActionResult EditProfile()
        {
            int studentId = (int)Session["studentid"]; // Get studentid from session
            StudentSignup student = _dal.GetStudentById(studentId);

            if (student != null)
            {
                return View(student); // Pass the student object to the view
            }
            return RedirectToAction("Index", "Home"); // Redirect if student not found
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateProfile(StudentSignup model)
        {
            if (ModelState.IsValid)
            {
                // Log or debug to confirm studentid is set
                Console.WriteLine("Updating student with ID: " + model.studentid);

                _dal.UpdateStudent(model);
                TempData["SuccessMessage"] = "Data updated successfully";
                return RedirectToAction("Profiles", "StudentSignup");
            }

            // If ModelState is not valid, return to the view with the same model
            return View("EditProfile", model);
        }
        public ActionResult ChangePassword()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ChangePassword(ChangePassword model)
        {
            // Check if student is logged in by verifying the studentid in the session
            int? studentId = Session["studentid"] as int?;
            if (studentId == null)
            {
                ModelState.AddModelError("", "Student not logged in.");
                return View(model);
            }

            // Fetch the student record from the database
            StudentSignup student = _dal.GetStudentById(studentId.Value);
            if (student == null)
            {
                ModelState.AddModelError("", "Student record not found.");
                return View(model);
            }

            // Log or debug the retrieved student password
            System.Diagnostics.Debug.WriteLine($"Retrieved Password: {student.password}");

            if (string.IsNullOrEmpty(student.password))
            {
                ModelState.AddModelError("", "Password is not set for the student.");
                return View(model);
            }

            // Convert to byte array if necessary (assuming it's stored as a string)
            string encryptedPasswordString = student.password;
            byte[] encryptedPassword = Convert.FromBase64String(encryptedPasswordString);

            // Decrypt the password
            string decryptedPassword = DecryptPassword(encryptedPassword);
            if (decryptedPassword == null)
            {
                ModelState.AddModelError("", "Unable to decrypt the password. Please try again.");
                return View(model);
            }

            // Compare the current password with the entered old password
            if (decryptedPassword != model.OldPassword)
            {
                ModelState.AddModelError("", "Current password is incorrect.");
                return View(model);
            }

            // Encrypt the new password and update it
            byte[] newEncryptedPassword = EncryptPassword(model.NewPassword);
            _dal.UpdatePassword(studentId.Value, newEncryptedPassword);

            // Success message
            TempData["SuccessMessage"] = "Password changed successfully.";
            return RedirectToAction("Profile");  // Redirect to another page, e.g., Profile
        }

        private byte[] EncryptPassword(string password)
        {
            if (string.IsNullOrEmpty(password))
            {
                throw new ArgumentNullException("password", "Password cannot be null or empty.");
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand command = new SqlCommand("SELECT EncryptByPassPhrase('YourSecretPassphrase', @password)", con);
                command.Parameters.AddWithValue("@password", password);
                var result = command.ExecuteScalar();

                return result as byte[]; // Ensure it returns a byte array or null
            }
        }
        private string DecryptPassword(byte[] encryptedPassword)
        {
            if (encryptedPassword == null)
            {
                throw new ArgumentNullException(nameof(encryptedPassword), "Encrypted password cannot be null.");
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand command = new SqlCommand("SELECT CONVERT(VARCHAR, DecryptByPassPhrase('YourSecretPassphrase', @encryptedPassword))", con);
                command.Parameters.AddWithValue("@encryptedPassword", encryptedPassword);

                object result = command.ExecuteScalar();

                // Check for null result from decryption
                if (result == null)
                {
                    return null; // Or throw an exception, depending on your needs
                }

                return result.ToString();
            }
        }




        // GET: StudentSignup/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: StudentSignup/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: StudentSignup/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: StudentSignup/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
