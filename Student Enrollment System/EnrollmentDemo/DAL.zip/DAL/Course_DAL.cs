﻿using EnrollmentDemo.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Drawing;

namespace EnrollmentDemo.DAL
{
    public class Course_DAL
    {
        string conString = ConfigurationManager.ConnectionStrings["dbConnectionString"]?.ToString();

        public List<Course> GetCourses()
        {
            List<Course> courses = new List<Course>();

            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Course", con);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Course course = new Course
                    {
                        courseid = (int)reader["courseid"],
                        coursename = reader["coursename"].ToString(),
                        description = reader["description"].ToString(),
                        duration = (int)reader["duration"],
                        seats = (int)reader["seats"]
                    };
                    courses.Add(course);
                }
            }

            return courses;
        }

        public bool AddCourse(Course course, out string errorMessage)
        {
            errorMessage = "";
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("InsertCourse", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@coursename", course.coursename);
                    cmd.Parameters.AddWithValue("@description", course.description);
                    cmd.Parameters.AddWithValue("@duration", course.duration);
                    cmd.Parameters.AddWithValue("@seats", course.seats);

                    cmd.ExecuteNonQuery();
                }
                return true;
            }
            catch (SqlException ex)
            {
                // Check if the error is due to duplicate course name
                if (ex.Number == 50000) // RAISERROR with severity 16 returns error number 50000
                {
                    errorMessage = ex.Message;
                    return false;
                }
                else
                {
                    throw;
                }
            }
        }
        // Enroll a student in a course (insert record in Enrollment table)
        public void EnrollStudent(int studentId, int courseId)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("EnrollStudent", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@studentid", studentId);
                cmd.Parameters.AddWithValue("@courseid", courseId);

                cmd.ExecuteNonQuery();  // Execute the stored procedure
            }
        }
        public void SaveCertificate(Certificate certificate)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                SqlCommand command = new SqlCommand("SaveCertificate", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@StudentId", certificate.StudentId);
                command.Parameters.AddWithValue("@CourseId", certificate.CourseId);
                command.Parameters.AddWithValue("@TenCertificatePath", certificate.TenCertificatePath);
                command.Parameters.AddWithValue("@PlusTwoCertificatePath", certificate.PlusTwoCertificatePath);


                con.Open();
                command.ExecuteNonQuery();
            }
        }
        public void UpdateEnrollmentStatus(int studentId, int courseId, string status)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                SqlCommand command = new SqlCommand("UpdateEnrollmentStatus", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@studentId", studentId);
                command.Parameters.AddWithValue("@courseId", courseId);
                command.Parameters.AddWithValue("@status", status);

                con.Open();
                command.ExecuteNonQuery();
            }
        }
        public List<Enrollment> GetEnrolledStudents()
        {
            List<Enrollment> enrollments = new List<Enrollment>();

            using (SqlConnection con = new SqlConnection(conString))
            {
                SqlCommand cmd = new SqlCommand("GetEnrolledStudents", con);
                cmd.CommandType = CommandType.StoredProcedure; // Specify that this is a stored procedure

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Enrollment enrollment = new Enrollment
                    {
                        EnrollId = (int)reader["enrollid"],
                        StudentId = (int)reader["studentid"],
                        CourseId = (int)reader["courseid"],
                        FirstName = reader["firstname"].ToString(),
                        LastName = reader["lastname"].ToString(),
                        CourseName = reader["coursename"].ToString(),
                        EnrollDate = (DateTime)reader["enrolldate"],
                        EnrollStatus = reader["enrollstatus"].ToString()
                    };
                    enrollments.Add(enrollment);
                }
            }

            return enrollments;
        }
        public Certificate GetCertificate(int studentId, int courseId)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                SqlCommand cmd = new SqlCommand("GetCertificate", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@StudentId", studentId);
                cmd.Parameters.AddWithValue("@CourseId", courseId);

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                Certificate certificate = null;
                if (reader.Read())
                {
                    certificate = new Certificate
                    {
                        TenCertificatePath = reader["TenCertificatePath"].ToString(),
                        PlusTwoCertificatePath = reader["PlusTwoCertificatePath"].ToString()
                    };
                }

                return certificate;
            }
        }
        public List<Enrollment> GetStudentEnrollments(int studentId)
        {
            List<Enrollment> enrollments = new List<Enrollment>();

            using (SqlConnection con = new SqlConnection(conString))
            {
                SqlCommand cmd = new SqlCommand("GetStudentEnrollments", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@studentId", studentId);

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Enrollment enrollment = new Enrollment
                    {
                        CourseId = (int)reader["courseid"],
                        CourseName = reader["coursename"].ToString(),
                        EnrollStatus = reader["enrollstatus"].ToString(),
                    };
                    enrollments.Add(enrollment);
                }
            }

            return enrollments;
        }
        public List<Enrollment> EnrolledStudents()
        {
            List<Enrollment> enrollments = new List<Enrollment>();
            using (SqlConnection con = new SqlConnection(conString))
            {
                SqlCommand cmd = new SqlCommand("EnrolledStudents", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Enrollment enrollment = new Enrollment
                    {
                        FirstName = rdr["firstname"].ToString(),
                        LastName = rdr["lastname"].ToString(),
                        CourseName = rdr["coursename"].ToString(),
                        EnrollStatus = rdr["enrollstatus"].ToString(),
                    };
                    enrollments.Add(enrollment);
                }
            }
            return enrollments;
        }

    }

}
