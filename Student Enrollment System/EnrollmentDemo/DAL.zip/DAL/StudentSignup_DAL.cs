﻿using EnrollmentDemo.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;

namespace EnrollmentDemo.DAL
{
    public class StudentSignup_DAL
    {
        string conString = ConfigurationManager.ConnectionStrings["dbConnectionstring"]?.ToString();
        public List<State> GetStates()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                SqlCommand command = new SqlCommand("SELECT * FROM State", con);
                SqlDataReader reader = command.ExecuteReader();
                List<State> states = new List<State>();
                while (reader.Read())
                {
                    states.Add(new State
                    {
                        stateid = (int)reader["stateid"],
                        statename = (string)reader["statename"]
                    });
                }
                return states;
            }
        }
        public List<City> GetCitiesByState(int stateId)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                SqlCommand command = new SqlCommand("GetCityByState", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@stateid", stateId);
                SqlDataReader reader = command.ExecuteReader();
                List<City> cities = new List<City>();
                while (reader.Read())
                {
                    cities.Add(new City
                    {
                        cityid = (int)reader["cityid"],
                        cityname = (string)reader["cityname"]
                    });
                }
                return cities;
            }
        }
        public void InsertStudent(StudentSignup model)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                SqlCommand command = new SqlCommand("InsertStudent", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@firstname", model.firstname);
                command.Parameters.AddWithValue("@lastname", model.lastname);
                command.Parameters.AddWithValue("@dob", model.dob);
                command.Parameters.AddWithValue("@gender", model.gender);
                command.Parameters.AddWithValue("@mail", model.mail);
                command.Parameters.AddWithValue("@phone", model.phone);
                command.Parameters.AddWithValue("@address", model.address);
                command.Parameters.AddWithValue("@state", model.state);
                command.Parameters.AddWithValue("@city", model.city);
                command.Parameters.AddWithValue("@username", model.username);
                // Encrypt the password before storing
                command.Parameters.AddWithValue("@password", model.password); // Model password should be plain text
                command.ExecuteNonQuery();
            }
        }
        public StudentSignup GetStudentByUsername(string username)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                SqlCommand command = new SqlCommand("GetStudentByUsername", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@username", username);

                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    StudentSignup student = new StudentSignup();
                    student.studentid = Convert.ToInt32(reader["studentid"]);
                    student.firstname = reader["firstname"].ToString();
                    student.lastname = reader["lastname"].ToString();
                    student.dob = Convert.ToDateTime(reader["dob"]);
                    student.gender = reader["gender"].ToString();
                    student.mail = reader["mail"].ToString();
                    student.phone = reader["phone"].ToString();
                    student.address = reader["address"].ToString();
                    student.username = reader["username"].ToString();

                    // Decrypted password handling
                    if (!(reader["DecryptedPassword"] is DBNull))
                    {
                        student.password = reader["DecryptedPassword"].ToString(); // Decrypted password
                        System.Diagnostics.Debug.WriteLine("Decrypted Password Retrieved: " + reader["DecryptedPassword"]);
                    }
                    else
                    {
                        student.password = null; // Handle case where password is null
                        System.Diagnostics.Debug.WriteLine("Password Retrieved: NULL");
                    }

                    return student;
                }
                return null;
            }
        }
        public List<StudentSignup> GetAllStudents()
        {
            List<StudentSignup> students = new List<StudentSignup>();
            using (SqlConnection con = new SqlConnection(conString))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM StudentSignup", con);
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    StudentSignup student = new StudentSignup
                    {
                        studentid = (int)rdr["studentid"],
                        firstname = rdr["firstname"].ToString(),
                        lastname = rdr["lastname"].ToString(),
                        dob = (DateTime)rdr["dob"],
                        mail = rdr["mail"].ToString(),
                        phone = rdr["phone"].ToString(),
                    };
                    students.Add(student);
                }
            }
            return students;
        }

        // Delete student by ID
        public void DeleteStudentById(int id)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM StudentSignup WHERE studentid = @studentid", con);
                cmd.Parameters.AddWithValue("@studentid", id);
                con.Open();
                cmd.ExecuteNonQuery();
            }
        }
        public StudentSignup GetStudentById(int studentId)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                SqlCommand command = new SqlCommand("GetStudentById", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@studentid", studentId);

                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    StudentSignup student = new StudentSignup
                    {
                        studentid = (int)reader["studentid"],
                        firstname = reader["firstname"].ToString(),
                        lastname = reader["lastname"].ToString(),
                        dob = Convert.ToDateTime(reader["dob"]),
                        gender = reader["gender"].ToString(),
                        mail = reader["mail"].ToString(),
                        phone = reader["phone"].ToString(),
                        address = reader["address"].ToString(),
                        username = reader["username"].ToString()
                    };
                    return student;
                }
                return null;
            }
        }
        public void UpdateStudent(StudentSignup model)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {

                SqlCommand command = new SqlCommand("UpdateStudent", con);
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.AddWithValue("@studentid", model.studentid);
                command.Parameters.AddWithValue("@firstname", model.firstname);
                command.Parameters.AddWithValue("@lastname", model.lastname);
                command.Parameters.AddWithValue("@dob", model.dob);
                command.Parameters.AddWithValue("@gender", model.gender);
                command.Parameters.AddWithValue("@mail", model.mail);
                command.Parameters.AddWithValue("@phone", model.phone);
                command.Parameters.AddWithValue("@address", model.address);
                //command.Parameters.AddWithValue("@state", model.state);
                //command.Parameters.AddWithValue("@city", model.city);

                con.Open();
                // Log or debug before executing
                Console.WriteLine("Executing update for student ID: " + model.studentid);
                command.ExecuteNonQuery();
            }
        }
        public void UpdatePassword(int studentId, byte[] newPassword)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                SqlCommand command = new SqlCommand("UPDATE StudentSignup SET password = @password WHERE studentid = @studentid", con);
                command.Parameters.AddWithValue("@password", newPassword);
                command.Parameters.AddWithValue("@studentid", studentId);
                command.ExecuteNonQuery();
            }
        }
    }
}