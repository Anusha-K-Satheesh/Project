﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EnrollmentDemo.Models
{
    public class Enrollment
    {
        public int EnrollId { get; set; }
        public int StudentId { get; set; }
        public int CourseId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string CourseName { get; set; }
        public DateTime EnrollDate { get; set; }
        public string EnrollStatus { get; set; }
        public string RejectReason { get; set; }
    }
}