﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EnrollmentDemo.Models
{
    public class Homeview
    {
        public string Title { get; set; }
        public string WelcomeMessage { get; set; }
    }
}