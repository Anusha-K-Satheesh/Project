﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace EnrollmentDemo.Models
{
    public class Course
    {
        public int courseid { get; set; }

        [Required(ErrorMessage = "Course Name is required")]
        [Display(Name = "Course Name")]
        public string coursename { get; set; }

        [Display(Name = "Course Description")]
        public string description { get; set; }

        [Required(ErrorMessage = "Course Duration is required")]
        [Display(Name = "Course Duration")]
        [Range(1, int.MaxValue, ErrorMessage = "Duration must be at least 1 year")]
        public int duration { get; set; }

        [Required(ErrorMessage = "Number of Seats is required")]
        [Display(Name = "Number of Seats")]
        [Range(1, int.MaxValue, ErrorMessage = "Number of seats must be at least 1")]
        public int seats { get; set; }
    }
}