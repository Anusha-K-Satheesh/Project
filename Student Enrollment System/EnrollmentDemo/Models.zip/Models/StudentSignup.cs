﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace EnrollmentDemo.Models
{
    public class StudentSignup
    {
        [Key]
        public int studentid { get; set; }
        [Required(ErrorMessage = "First name is required")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "First name should contain only characters")]
        [DisplayName("Firstname")]
        public string firstname { get; set; }
        [Required(ErrorMessage = "Last name is required")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Last name should contain only characters")]
        [DisplayName("Lastname")]
        public string lastname { get; set; }
        [Required]
        [DisplayName("Date of birth")]
        public DateTime dob { get; set; }
        [Required]
        [DisplayName("Gender")]
        public string gender { get; set; }
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        [DisplayName("Email")]
        public string mail { get; set; }
        [Required(ErrorMessage = "Phone number is required")]
        [RegularExpression(@"^[789]\d{9}$", ErrorMessage = "Enter valid Phone number.")]
        [DisplayName("Phone number")]
        public string phone { get; set; }
        [Required]
        [DisplayName("Address")]
        public string address { get; set; }
        [Required]
        [DisplayName("State")]
        public string state { get; set; }
        [Required]
        [DisplayName("City")]
        public string city { get; set; }
        [Required]
        [DisplayName("Username")]
        public string username { get; set; }
        [Required]
        [DisplayName("Password")]
        public string password { get; set; }
        [Required]
        [DisplayName("Confirm password")]
        [Compare("password", ErrorMessage = "Passwords do not match.")]
        public string confirmpassword { get; set; }
    }
    public class State
    {
        [Key]
        public int stateid { get; set; }
        [Required]
        [DisplayName("State")]
        public string statename { get; set; }
        public virtual ICollection<City> Cities { get; set; }  // Cities - collection of cities that belong to a specific state.
        // City - collection of City objects.
    }

    public class City
    {
        [Key]
        public int cityid { get; set; }
        [Required]
        [DisplayName("City")]
        public string cityname { get; set; }
        [Required]
        public int stateid { get; set; }
        public virtual State State { get; set; }  // State - holds a reference to a State object.
    }
}
