using VoipApp.Model;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();

// Configure Twilio settings
builder.Services.Configure<TwilioSettings>(builder.Configuration.GetSection("Twilio"));

// Add CORS policy for Vue app
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowVueApp", policy =>
    {
        policy.WithOrigins("http://localhost:8080") // Make sure this matches your Vue app's URL
              .AllowAnyMethod()
              .AllowAnyHeader()
              .AllowCredentials(); // If you are using authentication or cookies
    });
});

// Add Swagger for API documentation
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();  // Shows detailed error messages
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Apply the CORS policy **before** the other middlewares
app.UseCors("AllowVueApp"); // Keep this line here

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
