﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;
using VoipApp.Model;

namespace VoipApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CallController : ControllerBase
    {
        private readonly TwilioSettings _twilioSettings;

        public CallController(IOptions<TwilioSettings> twilioSettings)
        {
            _twilioSettings = twilioSettings.Value;
            TwilioClient.Init(_twilioSettings.AccountSid, _twilioSettings.AuthToken);
        }
        [HttpPost("make-call")]
        public IActionResult MakeCall([FromForm] string toPhoneNumber)
        {
            try
            {
                var to = new PhoneNumber(toPhoneNumber);
                var from = new PhoneNumber(_twilioSettings.TwilioPhoneNumber);
                var call = CallResource.Create(to, from, url: new Uri("http://demo.twilio.com/docs/voice.xml"));

                return Ok(call.Sid);
            }
            catch (Twilio.Exceptions.ApiException ex)
            {
                // Log the Twilio error
                Console.WriteLine($"Twilio API Error: {ex.Message}");
                return StatusCode(500, $"Twilio API Error: {ex.Message}");
            }
            catch (Exception ex)
            {
                // Log any other errors
                Console.WriteLine($"General Error: {ex.Message}");
                return StatusCode(500, $"General Error: {ex.Message}");
            }
        }

        [HttpPost("receive-call")]
        public IActionResult ReceiveCall([FromForm] string callSid)
        {
            // Logic for handling received calls
            return Ok("Received Call: " + callSid);
        }

        [HttpPost("mute-call")]
        public IActionResult MuteCall([FromForm] string callSid)
        {
            // Logic for muting the call using media stream or Twiml
            // Mute is typically done using Conferences, or you can programmatically adjust streams
            return Ok("Call Muted: " + callSid);
        }

        [HttpPost("unmute-call")]
        public IActionResult UnmuteCall([FromForm] string callSid)
        {
            // Logic for unmuting the call
            return Ok("Call Unmuted: " + callSid);
        }

        [HttpPost("pause-call")]
        public IActionResult PauseCall([FromForm] string callSid)
        {
            // To "pause" the call you may hang it up temporarily or transfer it to a holding endpoint
            var call = CallResource.Update(callSid, status: CallResource.UpdateStatusEnum.Completed);
            return Ok(call.Sid);
        }

        [HttpPost("continue-call")]
        public IActionResult ContinueCall([FromForm] string toPhoneNumber)
        {
            try
            {
                // Start a new call instead of trying to resume
                var to = new PhoneNumber(toPhoneNumber);
                var from = new PhoneNumber(_twilioSettings.TwilioPhoneNumber);
                var call = CallResource.Create(to, from, url: new Uri("http://demo.twilio.com/docs/voice.xml"));

                return Ok("New call started. Call SID: " + call.Sid);
            }
            catch (Twilio.Exceptions.ApiException ex)
            {
                // Handle Twilio errors
                Console.WriteLine($"Twilio API Error: {ex.Message}");
                return StatusCode(500, $"Twilio API Error: {ex.Message}");
            }
            catch (Exception ex)
            {
                // Handle general errors
                Console.WriteLine($"General Error: {ex.Message}");
                return StatusCode(500, $"General Error: {ex.Message}");
            }
        }
    }
}
