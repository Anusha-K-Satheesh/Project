﻿namespace NotificationAppDemo.Models
{
    public class NotificationMessage
    {
        public string Message { get; set; }
    }
}
