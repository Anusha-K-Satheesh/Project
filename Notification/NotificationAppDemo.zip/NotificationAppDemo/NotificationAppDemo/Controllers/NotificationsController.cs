﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using NotificationAppDemo.Models;

[ApiController]
[Route("api/[controller]")]
public class NotificationsController : ControllerBase
{
    private readonly IHubContext<NotificationHub> _hubContext;

    public NotificationsController(IHubContext<NotificationHub> hubContext)
    {
        _hubContext = hubContext;
    }

    [HttpPost("send")]
    public async Task<IActionResult> SendNotification([FromBody] NotificationMessage notification) // Use NotificationMessage
    {
        if (notification == null || string.IsNullOrEmpty(notification.Message)) // Check for null and empty message
        {
            return BadRequest(new { Message = "The message field is required." });
        }

        await _hubContext.Clients.All.SendAsync("ReceiveNotification", notification.Message);
        return Ok(new { Message = "Notification sent" });
    }
}
